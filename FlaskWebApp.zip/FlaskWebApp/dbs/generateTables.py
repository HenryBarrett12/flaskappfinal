import sqlite3

# Clears the tables and creates new ones
# this is in a different file because it is only used once / for testing
def generateTables():
    # establish connection
    conn = sqlite3.connect("dbs/database.db")
    # allows execution of SQL
    c = conn.cursor()

    # create user table
    c.executescript('''
    DROP TABLE if exists users;
    CREATE TABLE users
    (
    UID integer PRIMARY KEY AUTOINCREMENT , 
    name text, 
    username text, 
    password text,
    steam_id text
    );

    /* create games table */

    DROP TABLE if exists games;
    CREATE TABLE games
    (
    GID integer PRIMARY KEY , 
    name text
    );

    /* create usersgames table */

    DROP TABLE if exists usersgames;
    CREATE TABLE usersgames
    (
    
    UID integer, 
    GID integer,
    PRIMARY KEY(UID, GID)
    
    );
    ''')

    # commit changes
    conn.commit()
    # close connection
    conn.close()
