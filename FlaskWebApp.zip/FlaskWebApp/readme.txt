to run the server:
Either:
  --  install pycharm Pro or community and load the project
Or:
  --  Install python 3.6 + pip
  --  pip install virtualenv 
  --  cd to \venv\Scripts\
  --  run activate
  --  cd .. back to root
  --  run app.py
  --  When finished type: deactivate