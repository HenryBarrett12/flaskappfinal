# This file is only used to generate new crypto key and iv's.


from Crypto import Random
from Crypto.Cipher import AES


# Create a key for encryption
def createKey():
    print(Random.get_random_bytes(32))


# Create an iv - like a salt
def createIV():
    print(Random.new().read(AES.block_size))


def main():
    createKey()
    createIV()


if __name__ == "__main__":
    main()
