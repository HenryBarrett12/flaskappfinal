# Created by Henry Barrett
# This flask application lets users log in with Steam accounts and pick a random game from their games list.


import sqlite3
from Crypto import Random
from Crypto.Cipher import AES
from flask import Flask, render_template, url_for, redirect, request, session
from steam import WebAPI
import dbs.generateTables

# Necessary for the program to run:
app = Flask(__name__)
app.secret_key = "pretendthisisreallyhardtoguess"
# set api key - needed for steam api to work
api = WebAPI("D828891E0B7E50294A21DEA28A528B99")

# Encryption variables:
# set a key for encryption - generated from otherScripts/CryptoKey.py
key = b',Ejw-\x03K?\xff\x1f9\x91d\x0f\xbd{\xa8\x7f\x8f\x9c\xda\x11D\x0fU\x9f\xe7\xa5\x88}\xbe_'


# my_steam_id = 76561198066751995
# gabes steam_id = 76561198086525139

##############################################
# Program starts here:
##############################################
# index page
@app.route('/')
def index():
    games = None
    gameids = None
    # If a user is logged in
    if 'user' in session:
        # If the user has imported games into the db then send them to the page
        if user_has_imported():
            c = sql_execute(" SELECT name, GID FROM usersgames NATURAL JOIN games WHERE UID= ? ORDER BY name",
                            (session['UID'],))
            result = c.fetchall()
            # insert each game into a list.
            games = [item[0] for item in result]
            # insert the game id into a list so the game can be launched via id
            gameids = [item[1] for item in result]

    return render_template("/index.html", games=games, idlist=gameids)


# importgames page
@app.route("/importgames", methods=['GET', 'POST'])
def import_games():
    error_message = None
    # only access this page if logged in
    if 'user' in session:

        # has the user set their steam_id yet? If so has_id = true which shows the import button
        if user_steam_id(session['user'], False):
            # they do have an ID so tell importgames.html to show the correct form
            has_id = True

            # if user submitted data (clicked button)
            if request.method == 'POST':
                # fill the list with their steam games
                import_player_games(user_steam_id(session['user'], True))
                return redirect(url_for("index"))
        # they don't have a steam_id set
        else:
            # they don't have an ID so tell importgames.html to display the correct form (set steam_id)
            has_id = False

            # if they submitted data into the form
            if request.method == 'POST':
                # set steam_id as a variable
                steam_id = request.form['steam_id']
                # check if it is a valid ID
                response = api.ISteamUser.GetPlayerSummaries(steamids=steam_id)['response']['players']
                # if the api returns at least one value then it must be a valid id
                if len(response) > 0:
                    # Insert steam_id into the db
                    insert_player_steam_id(session['user'], steam_id)
                    # force refresh page
                    return redirect(url_for("import_games"))
                else:
                    # Error message
                    error_message = "INVALID STEAM ID"
        # load page with variable passed
        return render_template("importgames.html", has_id=has_id, error_message=error_message)
    # render the index page if they are not logged in
    return render_template("index.html")


# login function / page
@app.route("/login", methods=['GET', 'POST'])
def login():
    error = None
    # if user submitted data
    if request.method == 'POST':
        # set variables
        username = request.form['username']
        password = request.form['password']
        # check if credentials are in db [basic for test]
        if not check_credentials(username, password):
            error = "Invalid Credentials"
        else:
            # log in
            login_user(username)
            # redirect user to main page, logged in
            return redirect(url_for("index"))

    return render_template("login.html", error=error)


# create new user page
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    # setup some variables
    msg_error = None
    logout()
    # if user submits data
    if request.method == 'POST':
        # check if username already taken
        if check_user_exists(request.form['username']):
            msg_error = 'Username Taken'
        else:
            # set values from form
            username = request.form['username']
            name = request.form['name']
            password = request.form['password']
            # create new user
            create_user(username, name, password)
            # login
            login_user(username)
            # redirect to index, logged in
            return redirect(url_for("index"))

    return render_template('signup.html', error=msg_error)


# logout of sessions
@app.route("/logout")
def logout():
    session.pop('user', None)
    session.pop('name', None)
    session.pop('UID', None)
    return render_template('logout.html')


# testing: clear / reset db
@app.route('/resetdb')
def test_reset_db():
    create_tables()
    return redirect(url_for('signup'))


###############################################################
# Everything below here are functions / classes
###############################################################

# Imports a player's games into the database
def import_player_games(steam_id):
    # gather games library for any steam id
    dict_players_games = (api.IPlayerService.GetOwnedGames(steamid=steam_id, include_appinfo=False,
                                                           include_played_free_games=True, appids_filter=[]))
    # get list of 'games' inside 'response' dictionary
    list_player_games = dict_players_games["response"]["games"]

    # fetch every steam app as a dictionary. Also get just 'apps' list of dictionaries from result.
    list_all_steam_games = (api.ISteamApps.GetAppList())['applist']['apps']
    # loop through user's games and get the game name from the big list
    for game in list_player_games:
        # This is much more efficient than looping through the massive list of dictionaries.
        # 'next' does not store the list in memory and also stops as soon as it finds the item
        my_item = next((item for item in list_all_steam_games if item['appid'] == game['appid']), None)
        # add plaintext game name to 'list_game_names'

        # add values into appropriate tables in db
        # inserting into games table
        try:
            insert_game(game['appid'], my_item['name'])
        # if gid already in table do nothing
        except sqlite3.IntegrityError:
            # do nothing
            pass
        # inserting into usersgames table
        try:
            new_usersgame(session['UID'], game['appid'])
        # if key pair already in use
        except sqlite3.IntegrityError:
            # do nothing
            pass


# creates the tables, only used once / testing, kept here for evidence
def create_tables():
    dbs.generateTables.generateTables()


# Insert a new record into usergames
def new_usersgame(UID, GID):
    sql_execute("INSERT INTO usersgames(UID, GID) VALUES(?, ?)", (UID, GID,))


# insert game into games table
def insert_game(GID, name):
    sql_execute("INSERT INTO games(GID, name) VALUES(?, ?)", (GID, name,))


# checks if user in DB already (takes unique username)
def check_user_exists(username):
    # execute sql. get all users
    c = sql_execute(" SELECT COUNT(*) FROM users WHERE username= ? ", (username,))
    # result is a tuple type
    result = c.fetchone()
    # if the row count < 1; no results then no user, return false
    if result[0] < 1:
        return False
    else:
        return True


# create new user
def create_user(username, name, password):
    # execute sql. get all users
    # encrypt password
    password = encrypt(password, key)
    sql_execute("INSERT INTO users(name, username, password) VALUES(?,?,?)", (name, username, password,))


# get uid, name from username- return string
def results_from_username(username):
    c = sql_execute("SELECT UID, name FROM users WHERE username= ? ", (username,))
    # result is a tuple type
    result = c.fetchone()
    # return value of result, as list
    return result


# check credentials match a user in db
def check_credentials(username, password):
    # better practise to not decrypt the user's password into plain text in case of sql injection
    # we need to get the iv salt from the password in the db so the inputted value can be encrypted and compared
    c = sql_execute(" SELECT password FROM users WHERE username= ?", (username,))
    result = c.fetchone()
    iv = result[0][:AES.block_size]
    # encrypt the input and compare it to what is in the db
    password = encrypt(password, key, iv)
    c = sql_execute(" SELECT COUNT(*) FROM users WHERE username= ? AND password= ?", (username, password,))
    # result is a tuple type
    result = c.fetchone()
    # if the row count < 1; no results then no user with that combination, return false
    if result[0] < 1:
        return False
    else:
        return True


# logs the user into the session. stores name and username
def login_user(username):
    # set username in session
    session['user'] = username
    # set name in session
    name = results_from_username(username)[1]
    session['name'] = name
    # set UID in session
    UID = results_from_username(username)[0]
    session['UID'] = UID


# checks if a user in the db has a steam_id
def user_steam_id(username, return_id):
    # if return_id is true, return steam_id otherwise check if steam_id is in db, return boolean.
    if return_id:
        # execute sql
        c = sql_execute(" SELECT steam_id FROM users WHERE username= ? ", (username,))
        # return value of steam_id
        result = c.fetchone()
        return result[0]
    else:
        # execute sql
        c = sql_execute(" SELECT COUNT(steam_id) FROM users WHERE username= ? ", (username,))
        # result is a tuple type
        result = c.fetchone()
        # if there is no result in COUNT, no steam_id for that user
        if result[0] < 1:
            return False
        else:
            return True


# inserts a steam_id into the db where username ==
def insert_player_steam_id(username, steam_id):
    sql_execute("UPDATE users SET steam_id= ? WHERE username = ?", (steam_id, username,))


# this function executes sql using sqlite3.
def sql_execute(sql, parameters):
    # establish connection
    conn = sqlite3.connect("dbs/database.db")
    # allows execution of SQL
    c = conn.cursor()
    # execute sql.
    c.execute(sql, parameters)
    conn.commit()
    return c


# Checks to see if a specific user has imported any games yet
def user_has_imported():
    c = sql_execute(" SELECT COUNT(*) FROM usersgames WHERE UID = ? ", (session['UID'],))
    # Get first result
    result = c.fetchone()
    if result[0] < 1:
        return False
    else:
        return True


# pad a string to multiple of AES block size (16,32...)
def pad(s):
    return s + b"\0" * (AES.block_size - len(s) % AES.block_size)


# encrypt string
def encrypt(message, key, iv=None):
    message = pad(message.encode('utf-8'))
    # if encrypt is called with an iv, use it otherwise make anew one
    if iv is None:
        iv = Random.new().read(AES.block_size)
    else:
        iv = iv
    # create cipher instance
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return iv + cipher.encrypt(message)


# decrypt string
def decrypt(ciphertext, key):
    # get the iv from the front of the encrypted string
    iv = ciphertext[:AES.block_size]
    # create cipher instance
    cipher = AES.new(key, AES.MODE_CBC, iv)
    # decrypt
    plaintext = cipher.decrypt(ciphertext[AES.block_size:])
    # strip the 0 and decode it into python string from array
    return plaintext.rstrip(b"\0").decode('utf-8')


# Runs server - hide at the bottom out of the way ;)
if __name__ == "__main__":
    app.debug = True
    app.run()
